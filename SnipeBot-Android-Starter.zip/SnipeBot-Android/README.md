# SnipeBot Android starter (v0.1)

This is an Android Studio source project, not a compiled APK.

## What is implemented
- Android app shell with explicit Start and Stop controls.
- Android MediaProjection consent flow for each screen-capture session.
- Foreground notification with a Stop action.
- Accessibility-service declaration and a gated tap helper.
- Live screen-frame acquisition.

## What is intentionally not enabled yet
It does **not** automatically throw or tap. The supplied image is only one still frame and does not reveal:
- target angular velocity and direction,
- whether the target rotates continuously or changes between stages,
- what counts as a successful hit,
- whether the throw is triggered by a tap anywhere or a specific control,
- obstacle/chain collision rules.

Enabling automatic input before calibrating those rules could cause taps outside the game or repeated unwanted actions. The next development step is to collect a short screen recording (about 10–15 seconds) showing the target moving and at least one successful/failed throw, plus the game's name. Then implement target tracking, timing prediction, confidence checks, and a visible emergency stop.

## Build
1. Open this folder in Android Studio (recent stable version).
2. Let Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the APK on your Android device.
5. Enable SnipeBot game-control under Android Accessibility settings only when needed.
6. Start screen analysis and approve Android's screen-capture prompt.

The app requests screen capture only after you press Start. Stop from the app or its persistent notification. Android may require notification permission on newer versions.

## Notes
- Package: `com.example.snipebot`
- Minimum Android: 8.0 (API 26)
- Target SDK: 35
- No hidden operation, background persistence, or automatic tapping is included in this starter.
