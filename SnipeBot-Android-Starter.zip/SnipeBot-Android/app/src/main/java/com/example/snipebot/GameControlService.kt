package com.example.snipebot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class GameControlService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally does not act on unrelated apps or events.
    }
    override fun onInterrupt() {}

    // Kept gated and unused in this starter. It will only be called after
    // game-specific detection and a user-started session are implemented.
    fun tapAt(x: Float, y: Float, durationMs: Long = 45L) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }
}
