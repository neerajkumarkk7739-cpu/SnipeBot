package com.example.snipebot

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color

class MainActivity : Activity() {
    private val requestCapture = 7001
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Color.rgb(18, 25, 38))
        }
        val title = TextView(this).apply {
            text = "SnipeBot"
            textSize = 30f
            setTextColor(Color.WHITE)
        }
        status = TextView(this).apply {
            text = "Not running. Enable the control service, then start screen analysis."
            textSize = 16f
            setTextColor(Color.LTGRAY)
            setPadding(0, 28, 0, 28)
        }
        val accessibility = Button(this).apply {
            text = "Enable game-control permission"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val start = Button(this).apply {
            text = "Start screen analysis"
            setOnClickListener {
                val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mgr.createScreenCaptureIntent(), requestCapture)
            }
        }
        val stop = Button(this).apply {
            text = "Stop SnipeBot"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptureService::class.java))
                status.text = "Stopped."
            }
        }
        val note = TextView(this).apply {
            text = "Safety: screen capture is requested each session. Stop the service or revoke Accessibility access at any time. Automatic throws remain disabled until the game's timing and hit rules are calibrated from live frames."
            textSize = 14f
            setTextColor(Color.rgb(210, 220, 235))
            setPadding(0, 24, 0, 0)
        }
        layout.addView(title); layout.addView(status); layout.addView(accessibility)
        layout.addView(start); layout.addView(stop); layout.addView(note)
        setContentView(layout)
    }

    @Deprecated("Deprecated by Android but retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture && resultCode == RESULT_OK && data != null) {
            val intent = Intent(this, CaptureService::class.java).apply {
                putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(CaptureService.EXTRA_DATA, data)
            }
            startForegroundService(intent)
            status.text = "Screen analysis running. Open Snipe Time; use the notification to stop."
        } else if (requestCode == requestCapture) {
            status.text = "Screen-capture permission was not granted."
        }
    }
}
